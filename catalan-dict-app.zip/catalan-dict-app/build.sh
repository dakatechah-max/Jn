#!/usr/bin/env bash
# يتطلب: Node 18+ و JDK 17 و Android SDK (ANDROID_HOME)
set -e
npm install
[ -d android ] || npx cap add android
# تقييد المعمارية إلى arm64-v8a
grep -q abiFilters android/app/build.gradle || \
  sed -i '/defaultConfig {/a\        ndk { abiFilters "arm64-v8a" }' android/app/build.gradle
npx cap sync android
cd android && ./gradlew assembleDebug
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
