# بناء APK (arm64-v8a)

## الطريقة 1: بدون تثبيت أي شيء (GitHub)
1. أنشئ مستودعاً جديداً على github.com وارفع محتوى هذا المجلد كاملاً (بما فيه .github).
2. افتح تبويب Actions ← Build APK ← انتظر الانتهاء.
3. نزّل الملف app-debug-arm64 (يحتوي app-debug.apk).

## الطريقة 2: على جهازك
نفّذ ./build.sh (يتطلب Node 18+ و JDK 17 و Android SDK).
الناتج: android/app/build/outputs/apk/debug/app-debug.apk

لتغيير اسم الحزمة عدّل appId في capacitor.config.json.
